#include <stdio.h>
#include <stdlib.h>
#include "asa.h"


int main()
{
  node *p1, *p2, *p3, *p4, *p5;
  
  p1 = create_nodeNb( 2 );
  p2 = create_nodeNb( 3 );
  p3 = create_nodeOp( '*', 2, p1, p2 );
  p4 = create_nodeNb( 1 );
  p5 = create_nodeOp( '+', 2, p3, p4 );

  printf("1 + 2 * 3 = %d\n",eval(p5));
  free_node(p5);
}
