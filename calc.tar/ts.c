#include "ts.h"

table_symb * ts_create_id(char *id, int val)
{
  table_symb *t;
  return t;
}

void ts_assign_value(table_symb * t, char *id, int val)
{
  return 0;
}

int ts_get_value(table_symb *t, char *id)
{
  return 0;
  
}

void ts_free_table(table_symb *t)
{
  
}

void ts_print(table_symb *t)
{
  printf("\n");
}
