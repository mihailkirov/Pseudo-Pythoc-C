#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

typedef enum { typeNb, typeOp } nodeType;

typedef struct {
  int value;
} nodeNb;

typedef struct {
  int ope;
  int nops;
  struct node ** node;
} nodeOp;

typedef struct node{
  nodeType type;

  union {
    nodeNb nb;
    nodeOp op;
  };
} node;

void yyerror(char * s);

/*
  Crée une feuille contenant un entier
 */
node * create_nodeNb(int value);

/*
  Crée un noeud d'correspondant à l'opération <ope> dont le nombre
  d'opérandes est <nops> et dont les opérandes sont listées ensuite
*/
node * create_nodeOp(int ope, int nops, ...);

/*
  libère la mémoire du sous-arbre dont la racine est <p>
*/
void free_node(node *p);

/*
  Évalue la valeur d'attribut du sous arbre dont la racine est <p>
*/
int eval(node *p);


