#include "asa.h"

node * create_nodeNb(int value)
{
  node *p =NULL;
  return p;
}

node * create_nodeOp(int ope, int nops, ...)
{
  node * p=NULL;
  return p;
}
void free_node(node *p)
{
}

int eval(node *p)
{
  return 0;
}

void yyerror(char * s)
{
}
