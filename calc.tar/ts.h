#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct table_symb{
  char *id;
  int val;
  struct table_symb *next;
} table_symb;   


/* 
   cree une structure de type table_symb initialisée avec les valeurs
   <id> et <val>
*/
table_symb * ts_create_id(char *id, int val);

/* 
   affecte la valeur <val> à l'identificateur <id> s'il existe dans la
   table, l'ajoute en fin de table sinon   
 */
void ts_assign_value(table_symb * t, char *id, int val);

/*
  retourne la valeur de l'identificateur <id>
*/
int ts_get_value(table_symb *t, char *id);

void ts_free_table(table_symb *t);
void ts_print(table_symb *t);
